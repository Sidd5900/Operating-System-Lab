Enter the number of requests:
5
Enter the requests:
23 89 132 42 187
Total head movement for fcfs = 421
Total head movement for scan = 275
Total head movement for cscan = 387
Total head movement for sstf = 273
Total seek time for fcfs (in milliseconds)= 2105
Total seek time for scan = 1375
Total seek time for cscan = 1935
Total seek time for sstf = 1365
Order of algoritms in ascending order of seek time:
SSTF SCAN CSCAN FCFS