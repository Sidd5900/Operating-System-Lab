Sample Input and Output:
Testcase 1:

8 10 4
2
0 2 5 7
a 64
64 bytes has been allocated in frame numbers 3 4 8 9
t 43
the physical address is- 139
t 241
invalid page number
d 1
page no 1 has been deleted
a 32
32 bytes has been allocated in frame numbers 4 10



Testcase 2:
8 10 4
2
0 2 5 6
a 64
64 bytes has been allocated in frame numbers 3 4 7 8
t 43
the physical address is- 123
t 241
invalid page number
d 1
page no 1 has been deleted
a 32
32 bytes has been allocated in frame numbers 4 9
a 16
16 bytes has been allocated in frame numbers 10
t 42
the physical address is- 122